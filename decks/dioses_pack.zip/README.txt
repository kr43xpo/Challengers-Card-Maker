================================================================================
 CHALLENGERS! - EXPANSIÓN TEMÁTICA DIOSES (EDICIÓN EQUILIBRADA)
================================================================================

[ES] ESPAÑOL
--------------------------------------------------------------------------------
Este mazo temático introduce a las deidades y figuras supremas de cinco
grandes tradiciones de la humanidad: Egipcia, Griega, Hindú, Nórdica y
Cristiana. 

ESTRUCTURA DE BALANCE OFICIAL:
Cada una de las cinco facciones calca exactamente la distribución de cartas,
niveles (A, B, C), valores de fuerza y número de copias oficiales (40 copias
por conjunto), garantizando una experiencia 100% fiel y competitiva.

DISTRIBUCIÓN POR CONJUNTO (40 COPIAS CADA UNO):

1. PANTEÓN EGIPCIO (Duat) [Basado en Bosque Mágico / Fairytale Forest]:
   • Nivel A (18 copias): Anubis (Str 1, 4x), Osiris (Str 2, 7x), Bastet (Str 3, 3x), Thot (Str 4, 4x)
   • Nivel B (14 copias): Isis (Str 1, 4x), Horus (Str 4, 4x), Sobek (Str 5, 3x), Seth (Str 7, 3x)
   • Nivel C (8 copias): Ra (Str 4, 4x), Sekhmet (Str 7, 2x), Amón-Ra (Str 8, 2x)
   Total: 11 cartas únicas (40 copias).

2. PANTEÓN GRIEGO (Olimpo) [Basado en Montaña / Mountain Top]:
   • Nivel A (16 copias): Afrodita (Str 2, 4x), Apolo (Str 2, 4x), Hermes (Str 3, 5x), Dioniso (Str 3, 3x)
   • Nivel B (15 copias): Atenea (Str 3, 4x), Hades (Str 4, 4x), Hefesto (Str 4, 4x), Ares (Str 5, 3x)
   • Nivel C (9 copias): Hera (Str 6, 4x), Poseidón (Str 7, 2x), Zeus (Str 11, 3x)
   Total: 11 cartas únicas (40 copias).

3. PANTEÓN HINDÚ (Vedas) [Basado en Club de Playa / Beach Club]:
   • Nivel A (14 copias): Ganesha (Str 1, 3x), Surya (Str 2, 4x), Rama (Str 2, 4x), Parvati (Str 3, 3x)
   • Nivel B (15 copias): Saraswati (Str 3, 4x), Kali (Str 3, 4x), Krishna (Str 4, 4x), Hanuman (Str 5, 3x)
   • Nivel C (11 copias): Brahma (Str 4, 4x), Vishnu (Str 6, 5x), Shiva (Str 7, 2x)
   Total: 11 cartas únicas (40 copias).

4. PANTEÓN NÓRDICO (Asgard) [Basado en Castillo / Castle]:
   • Nivel A (15 copias): Heimdall (Str 1, 4x), Baldr (Str 2, 4x), Idunn (Str 2, 4x), Bragi (Str 3, 3x)
   • Nivel B (15 copias): Tyr (Str 3, 4x), Freyja (Str 3, 4x), Loki (Str 4, 4x), Freyr (Str 5, 3x)
   • Nivel C (10 copias): Odín (Str 4, 4x), Frigg (Str 5, 4x), Thor (Str 7, 2x)
   Total: 11 cartas únicas (40 copias).

5. FIGURAS CRISTIANAS (Cielo) [Basado en Universidad / University]:
   • Nivel A (15 copias): Abraham (Str 1, 4x), Juan el Bautista (Str 2, 4x), María (Str 2, 4x), María Magdalena (Str 3, 3x)
   • Nivel B (15 copias): San Agustín (Str 3, 4x), Juan el Evangelista (Str 4, 4x), San Pedro (Str 4, 4x), San Pablo (Str 5, 3x)
   • Nivel C (10 copias): Rey David (Str 3, 4x), Moisés (Str 5, 4x), Jesús (Str 7, 2x)
   Total: 11 cartas únicas (40 copias).

TOTAL DEL PAQUETE: 55 modelos únicos de cartas / 200 cartas jugables (40 x 5).

--------------------------------------------------------------------------------
[EN] ENGLISH
--------------------------------------------------------------------------------
This thematic expansion introduces gods and divine figures from five major
pantheons and spiritual traditions: Egyptian, Greek, Hindu, Norse, and
Christian. Every set precisely mirrors the official card counts, power levels,
and copies (40 copies per set, 200 copies total), preserving perfect competitive
gameplay balance.

Sets included:
1. Egyptian Pantheon (Duat) - Mirrors Fairytale Forest (11 cards, 40 copies)
2. Greek Pantheon (Olympus) - Mirrors Mountain Top (11 cards, 40 copies)
3. Hindu Pantheon (Vedas) - Mirrors Beach Club (11 cards, 40 copies)
4. Norse Pantheon (Asgard) - Mirrors Castle (11 cards, 40 copies)
5. Christian Figures (Heaven) - Mirrors University (11 cards, 40 copies)

--------------------------------------------------------------------------------
[FR] FRANÇAIS
--------------------------------------------------------------------------------
Cette extension thématique met en scène les divinités et grandes figures de
cinq traditions majeures : Égyptienne, Grecque, Hindoue, Nordique et Chrétienne.
Chaque faction reproduit exactement la distribution officielle de Challengers!
(11 cartes uniques, 40 exemplaires par faction, 200 cartes au total).

Factions incluses :
1. Panthéon Égyptien (Douat) - Reproduit Forêt Magique (11 cartes, 40 copies)
2. Panthéon Grec (Olympe) - Reproduit Sommet de la Montagne (11 cartes, 40 copies)
3. Panthéon Hindou (Védas) - Reproduit Club de Plage (11 cartes, 40 copies)
4. Panthéon Nordique (Asgard) - Reproduit Château (11 cartes, 40 copies)
5. Figures Chrétiennes (Ciel) - Reproduit Université (11 cartes, 40 copies)

--------------------------------------------------------------------------------
[DE] DEUTSCH
--------------------------------------------------------------------------------
Diese thematische Erweiterung führt Gottheiten und Gestalten aus fünf großen
Traditionen der Menschheit ein: Ägyptisch, Griechisch, Hindu, Nordisch und
Christlich. Jede Fraktion reproduziert exakt die offizielle Kartenverteilung von
Challengers! (11 einzigartige Karten, 40 Exemplare pro Fraktion, 200 Karten insgesamt).

Enthaltene Fraktionen:
1. Ägyptisches Pantheon (Duat) - Entspricht Märchenwald (11 Karten, 40 Exemplare)
2. Griechisches Pantheon (Olymp) - Entspricht Berggipfel (11 Karten, 40 Exemplare)
3. Hindugötter (Veden) - Entspricht Strandclub (11 Karten, 40 Exemplare)
4. Nordisches Pantheon (Asgard) - Entspricht Burg (11 Karten, 40 Exemplare)
5. Biblische Figuren (Himmel) - Entspricht Universität (11 Karten, 40 Exemplare)

--------------------------------------------------------------------------------
[NL] NEDERLANDS
--------------------------------------------------------------------------------
Deze thematische uitbreiding introduceert goden en verheven figuren uit vijf grote
tradities van de mensheid: Egyptisch, Grieks, Hindoe, Noors en Christelijk.
Elke factie weerspiegelt exact de officiële kaartverdeling van Challengers!
(11 unieke kaarten, 40 exemplaren per factie, 200 kaarten in totaal).

Inbegrepen facties:
1. Egyptisch Pantheon (Duaat) - Weerspiegelt Sprookjesbos (11 kaarten, 40 exemplaren)
2. Grieks Pantheon (Olympus) - Weerspiegelt Bergtop (11 kaarten, 40 exemplaren)
3. Hindoeïstisch Pantheon (Veda's) - Weerspiegelt Strandclub (11 kaarten, 40 exemplaren)
4. Noors Pantheon (Asgard) - Weerspiegelt Kasteel (11 kaarten, 40 exemplaren)
5. Christelijke Figuren (Hemel) - Weerspiegelt Universiteit (11 kaarten, 40 exemplaren)

--------------------------------------------------------------------------------
[IT] ITALIANO
--------------------------------------------------------------------------------
Questa espansione tematica introduce divinità e figure supreme di cinque grandi
tradizioni dell'umanità: Egizia, Greca, Indù, Norrena e Cristiana.
Ciascuna fazione replica esattamente la distribuzione ufficiale di Challengers!
(11 carte uniche, 40 copie per fazione, 200 carte in totale).

Fazioni incluse:
1. Pantheon Egizio (Duat) - Basato su Bosco Incantato (11 carte, 40 copie)
2. Pantheon Greco (Olimpo) - Basato su Cima della Montagna (11 carte, 40 copie)
3. Pantheon Indù (Veda) - Basato su Beach Club (11 carte, 40 copie)
4. Pantheon Norreno (Asgard) - Basato su Castello (11 carte, 40 copie)
5. Figure Cristiane (Cielo) - Basato su Università (11 carte, 40 copie)
================================================================================
