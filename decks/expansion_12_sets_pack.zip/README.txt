CHALLENGERS! - EXPANSIÓN 12 CONJUNTOS PERSONALIZADOS
================================================================================
Autor / Creador: strezah
Adaptación para Visor de Cartas: Antigravity Challengers Suite
Versión: 1.0 (2026)

DESCRIPCIÓN GENERAL / OVERVIEW
--------------------------------------------------------------------------------
Esta expansión comunitaria creada por strezah aporta 12 nuevos conjuntos temáticos para Challengers!
con un total de 129 cartas únicas y 480 cartas para juego competitivo (40 copias por facción).

Cada facción respeta escrupulosamente el equilibrio canónico de Challengers!:
- Nivel A: 15 copias
- Nivel B: 15 copias
- Nivel C: 10 copias
Total por facción: 40 copias (12 facciones x 40 = 480 cartas).

FACCIONES INCLUIDAS / FACTIONS
--------------------------------------------------------------------------------
1. Secta Oscura (Dark Cult)        - 11 cartas (40 copias) - Color: Púrpura  (#7c3aed)
2. Inframundo (Underworld)         - 11 cartas (40 copias) - Color: Rojo     (#dc2626)
3. Japón Feudal (Feudal Japan)     - 11 cartas (40 copias) - Color: Gris     (#1f2937)
4. Prehistoria (Prehistoric)       - 10 cartas (40 copias) - Color: Ámbar    (#b45309)
5. Viejo Oeste (Wild West)         - 11 cartas (40 copias) - Color: Marrón   (#92400e)
6. Celestial (Celestial)           - 11 cartas (40 copias) - Color: Dorado   (#eab308)
7. Fuerza Aérea (Air Force)        - 10 cartas (40 copias) - Color: Celeste  (#0284c7)
8. Casino y Apuestas (Casino)      - 10 cartas (40 copias) - Color: Esmeralda(#059669)
9. Mitología Clásica (Mythology)   - 11 cartas (40 copias) - Color: Azul     (#1d4ed8)
10. Eruditos y Museo (Scholars)    - 11 cartas (40 copias) - Color: Rosa Osc.(#831843)
11. Infiltración (Space Impostor)  - 11 cartas (40 copias) - Color: Cian     (#0891b2)
12. Antiguo Egipto (Egyptian)      - 11 cartas (40 copias) - Color: Amarillo (#ca8a04)

ESTRUCTURA DEL PAQUETE ZIP
--------------------------------------------------------------------------------
- cards.json                  -> Definición de cartas, facciones, metadatos y traducciones
- README.txt                  -> Este manual informativo
- images/art_digital/         -> 129 ilustraciones normalizadas JPG (640x640)
- images/icons/               -> 12 iconos monocromáticos oficiales de las facciones
- icons/                      -> Copia de seguridad de los 12 iconos

COMPATIBILIDAD
--------------------------------------------------------------------------------
Compatible con Challengers! 1, Challengers! 2 (Beach Cup) y el visor interactivo web.
Todos los textos están traducidos a: Español (ES), English (EN), Français (FR),
Deutsch (DE), Nederlands (NL) e Italiano (IT).
