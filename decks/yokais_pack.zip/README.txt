================================================================================
 ESPAÑOL - RESUMEN DEL CONTENIDO Y DETALLE DEL MAZO
================================================================================
• Contenido (11 cartas únicas / 46 copias en total):

  • 8 mazos de inicio (6 cartas por mazo con los símbolos de jugador).
  • 1 conjuntos adicionales (46 cartas en cada uno):
    1. Yokais (Base Secreta) (Yokais (Secret Base)) — 11 cartas.

--- DETALLE CARTA POR CARTA (ESPAÑOL) ---

[CONJUNTO / FACCIÓN: YOKAIS (BASE SECRETA)] (11 modelos de carta, 46 copias)
  • [Nivel A] Chochin-obake | Fuerza: 1 | Copias: 4
    Efecto: Toma la carta superior del mazo de nivel A y colócala en tu reserva.
  • [Nivel A] Nekomata | Fuerza: 2 | Copias: 8
    Efecto: _Durante el ataque:_ Esta carta gana +1 por cada carta en tu reserva.
  • [Nivel A] Kappa | Fuerza: 3 | Copias: 3
    Efecto: Infrecuente (3 copias)
  • [Nivel B] Bake-danuki | Fuerza: 3 | Copias: 4
    Efecto: Coloca una carta de tu reserva en la parte inferior de tu mazo.
  • [Nivel B] Tengu | Fuerza: 3 | Copias: 4
    Efecto: Coloca hasta dos cartas [Yokais] de tu banquillo en tu reserva.
  • [Nivel B] Kitsune | Fuerza: 5 | Copias: 4
    Efecto: Mira las tres primeras cartas de tu mazo. Coloca una en la parte superior de tu mazo, una en la parte inferior y una en tu reserva.
  • [Nivel B] Jorogumo | Fuerza: 5 | Copias: 3
    Efecto: Infrecuente (3 copias)
  • [Nivel C] Yuki-Onna | Fuerza: 3 | Copias: 4
    Efecto: _Especial:_ En lugar de ir a tu banquillo, esta carta va a tu reserva.
  • [Nivel C] Oni | Fuerza: 5 | Copias: 4
    Efecto: Coloca una carta de nivel A de tu banquillo en la parte superior de tu mazo.
  • [Nivel C] Gashadokuro | Fuerza: 7 | Copias: 2
    Efecto: Infrecuente (2 copias)
  • [Nivel S] Shikigami Inicial | Fuerza: ? | Copias: 6
    Efecto: La fuerza base de esta carta es igual al número de la ronda.

================================================================================
 ENGLISH - CONTENT SUMMARY AND CARD-BY-CARD DETAILS
================================================================================
• Content (11 unique cards / 46 total copies):

  • 8 starter decks (6 cards each with player tournament icons).
  • 1 additional sets (46 cards each):
    1. Yokais (Secret Base) — 11 cards.

--- CARD-BY-CARD DETAILS (ENGLISH) ---

[SET / FACTION: YOKAIS (SECRET BASE)] (11 card models, 46 copies)
  • [Level A] Chochin-obake | Power: 1 | Copies: 4
    Effect: Put the top card from the Level-A-Pile on your exhaust pile.
  • [Level A] Nekomata | Power: 2 | Copies: 8
    Effect: During the attack: This card has +1 for each card in your exhaust pile.
  • [Level A] Kappa | Power: 3 | Copies: 3
    Effect: Rare 3x
  • [Level B] Bake-danuki | Power: 3 | Copies: 4
    Effect: Put a card from your exhaust pile under your deck.
  • [Level B] Tengu | Power: 3 | Copies: 4
    Effect: Put up to two [Yokais]-cards from your bench on your exhaust pile.
  • [Level B] Kitsune | Power: 5 | Copies: 4
    Effect: Look at the top three cards of your deck. Put one under, one on the top of your deck and one on your exhaust pile.
  • [Level B] Jorogumo | Power: 5 | Copies: 3
    Effect: Rare 3x
  • [Level C] Yuki-Onna | Power: 3 | Copies: 4
    Effect: Special: When this card would be put on your bench, put it on your exhaust pile instead.
  • [Level C] Oni | Power: 5 | Copies: 4
    Effect: Put a Level-A-Card from your bench on top of your deck.
  • [Level C] Gashadokuro | Power: 7 | Copies: 2
    Effect: Rare 2x
  • [Level S] Starter Shikigami | Power: ? | Copies: 6
    Effect: This card's base power is equal to the current round.

================================================================================
 FRANÇAIS - RÉSUMÉ DU CONTENU ET DÉTAIL DES CARTES
================================================================================
• Contenu (11 cartes uniques / 46 exemplaires au total) :

  • 8 decks de départ (6 cartes par deck avec les symboles de joueur).
  • 1 ensembles additionnels (46 cartes dans chaque ensemble) :
    1. Yokais (Infiltration) — 11 cartes.

--- DÉTAIL CARTE PAR CARTE (FRANÇAIS) ---

[ENSEMBLE / FACTION : YOKAIS (INFILTRATION)] (11 modèles de carte, 46 exemplaires)
  • [Niveau A] Chochin-obake | Force : 1 | Exemplaires : 4
    Effet : Prenez la carte du dessus de la pile niveau A et placez-la sur votre réserve.
  • [Niveau A] Nekomata | Force : 2 | Exemplaires : 8
    Effet : Durant l'attaque : Cette carte gagne +1 pour chaque carte dans votre réserve.
  • [Niveau A] Kappa | Force : 3 | Exemplaires : 3
    Effet : Rare 3x
  • [Niveau B] Bake-danuki | Force : 3 | Exemplaires : 4
    Effet : Placez une carte de votre réserve en dessous de votre deck.
  • [Niveau B] Tengu | Force : 3 | Exemplaires : 4
    Effet : Placez jusqu'à deux cartes [Yokais] de votre banc sur votre réserve.
  • [Niveau B] Kitsune | Force : 5 | Exemplaires : 4
    Effet : Regardez les trois premières cartes de votre deck. Placez-en une au-dessus de votre deck, une en dessous, et une sur votre réserve.
  • [Niveau B] Jorogumo | Force : 5 | Exemplaires : 3
    Effet : Rare 3x
  • [Niveau C] Yuki-Onna | Force : 3 | Exemplaires : 4
    Effet : Spécial : Au lieu d'être placée sur votre banc, cette carte est placée sur votre réserve.
  • [Niveau C] Oni | Force : 5 | Exemplaires : 4
    Effet : Placez une carte niveau A de votre banc sur le dessus de votre deck.
  • [Niveau C] Gashadokuro | Force : 7 | Exemplaires : 2
    Effet : Rare 2x
  • [Niveau S] Shikigami Initial | Force : ? | Exemplaires : 6
    Effet : La force de base de cette carte est égale au numéro de la manche.

================================================================================
CHALLENGERS! CARD VIEWER - OFFICIAL COMPATIBLE PACKAGE
================================================================================